---
name: frontend-design
description: Frontend UI development best practices for AI coding agents. Covers component design, state management, responsive design, accessibility, and performance.
---

# Frontend Design Skill — UI Development Best Practices

You are building frontend interfaces. Follow these guidelines for all UI work.

## Component Design

### Principles
1. **Single Responsibility** — Each component does one thing well
2. **Composition over Inheritance** — Build complex UIs from small, focused components
3. **Props Down, Events Up** — Data flows down via props, actions bubble up via events
4. **Controlled Components** — Let the parent manage state when possible

### Component Structure
```
Component/
├── ComponentName.vue     # Component template, script, style
├── useComponentName.js   # Composable (if logic is complex)
└── ComponentName.test.js # Tests
```

### Naming Conventions
- Components: PascalCase (`UserProfile.vue`, `TaskCard.vue`)
- Props/Events: camelCase (`userName`, `@item-click`)
- CSS classes: kebab-case (`user-profile`, `task-card`)
- Composables: `use` prefix (`useAuth.js`, `useTaskList.js`)

## State Management

### When to Use Local State
- UI-only state (modals open, form inputs, hover states)
- Data that doesn't need to be shared

### When to Use Global Store (Pinia/Vuex)
- User session/auth data
- Data shared across multiple views
- Cached API responses
- Application-wide settings

### State Management Rules
1. **Normalize data** — Store flat lists with IDs, not nested objects
2. **Single source of truth** — Don't duplicate data across stores
3. **Actions for async** — API calls go in actions, not components
4. **Getters for derived data** — Computed values from store state

## Responsive Design

### Breakpoints
```
Mobile:    < 768px
Tablet:    768px - 1024px
Desktop:   > 1024px
```

### Rules
1. **Mobile-first** — Start with mobile layout, add complexity for larger screens
2. **Relative units** — Use `rem`, `em`, `%` instead of fixed `px` where possible
3. **Flexbox/Grid** — Use CSS Grid for 2D layouts, Flexbox for 1D alignment
4. **Test on real devices** — Browser dev tools are not enough
5. **Content-aware** — Design for varying content lengths, not just ideal data

## Accessibility (a11y)

### Required
- **Semantic HTML** — Use `<button>`, `<nav>`, `<main>`, `<article>` instead of `<div>`
- **ARIA labels** — Add `aria-label` for interactive elements without visible text
- **Keyboard navigation** — All interactive elements must be focusable and usable with keyboard
- **Color contrast** — Minimum 4.5:1 ratio for text, 3:1 for large text
- **Focus management** — Visible focus indicators, logical tab order

### Testing
- Navigate the entire page using only Tab/Enter/Escape
- Check with screen reader (VoiceOver/NVDA)
- Verify color contrast with accessibility tools

## Performance

### Optimization Checklist
- [ ] **Lazy load routes** — Use dynamic imports for route components
- [ ] **Image optimization** — Use WebP, lazy load below-fold images
- [ ] **Bundle size** — Tree-shake unused imports, use code splitting
- [ ] **Virtual scrolling** — For lists > 100 items
- [ ] **Debounce inputs** — Search, resize, scroll handlers
- [ ] **Memoize expensive computations** — `computed` or `useMemo`
- [ ] **Avoid unnecessary re-renders** — Use `v-once`, `v-memo`, stable keys in lists

### Anti-Patterns
- Fetching all data upfront when paginating
- Inline styles for dynamic values that change frequently
- Deep watchers on large objects
- Synchronous layout calculations in render

## Error Handling in UI

1. **Network errors** — Show user-friendly message with retry button
2. **Form validation** — Validate on blur, show errors inline near the field
3. **Loading states** — Show skeleton/spinner, never blank screen
4. **Empty states** — Show helpful message when no data, not just a blank list
5. **Error boundaries** — Catch rendering errors gracefully
